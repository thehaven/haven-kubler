A Calibre plug-in to download high-resolution cover images from Amazon.
Only Kindle books are supported.

This plug-in uses the technique published at:
https://www.ereader-palace.com/get-high-resolution-cover-image-amazon-kindle-ebooks/

